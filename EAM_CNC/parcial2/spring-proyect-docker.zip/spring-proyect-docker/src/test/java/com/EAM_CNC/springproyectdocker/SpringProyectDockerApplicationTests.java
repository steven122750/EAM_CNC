package com.EAM_CNC.springproyectdocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProyectDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
